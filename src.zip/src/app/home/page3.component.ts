import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page3',
  template: `<h1>me is page3</h1>`,
})
export class Page3Component  {

}