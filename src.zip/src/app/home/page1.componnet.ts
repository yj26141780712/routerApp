import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page1',
  template: `<h1>me is page1</h1>`,
})
export class Page1Component  {

}