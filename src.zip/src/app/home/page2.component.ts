import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page2',
  template: `<h1>me is page2</h1>`,
})
export class Page2Component  {

}