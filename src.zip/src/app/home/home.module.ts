import { Page2Component } from './page2.component';
import { HomeComponent } from './home.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeRoutingModule } from './home-routing.module';
import { Page1Component } from './page1.componnet';
import { Page3Component } from './page3.component';

@NgModule({
  imports: [
    CommonModule,
    HomeRoutingModule
  ],
  exports:[],
  declarations:[HomeComponent,Page1Component,Page2Component,Page3Component],
  bootstrap:[Page1Component] 
})
export class HomeModule { }
