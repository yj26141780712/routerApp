
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home.component';
import { Page1Component } from './page1.componnet';
import { Page3Component } from './page3.component';
import { Page2Component } from './page2.component';



const homeRoutes: Routes = [
  {
    path: '',
    component: HomeComponent,
    children: [
      {
        path: '',
        children: [
          { path: 'page1', component: Page1Component },
          { path: 'page2', component: Page2Component },
          { path: 'page3', component: Page3Component }
        ]
      }
    ]
  }
];

@NgModule({
imports: [ RouterModule.forChild(homeRoutes) ],
exports: [ RouterModule ],
declarations: []
})
export class HomeRoutingModule { }
